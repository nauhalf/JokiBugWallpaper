package com.muuandmuu.template;

import android.app.Activity;

/**
 * Created by kingdov on 17/01/2017.
 */

public class SettingsClasse extends Activity{
	public static String contactMail = "muuandmuu.dev@gmail.com";
	public static int interstitialFrequence = 15;
	public static String admBanner   ="ca-app-pub-3940256099942544/6300978111"; //adtest
	public static String Interstitial ="ca-app-pub-3940256099942544/1033173712"; //adtest
//	public static String admBanner   ="ca-app-pub-1636959695432135/4202974596";
//	public static String Interstitial ="ca-app-pub-1636959695432135/9760700835";
	public static String privacy_policy_url = "https://muuandmuu.wordpress.com/privacy-policy/";
	public static String more_apps_link = "https://play.google.com/store/apps/developer?id=muu%26muu";

	public static Boolean isOnlineDB = true; // true = online, false = offline

	//online url
	public static String wallpaperDataBase = "https://www.dropbox.com/s/aezut4asldzhu6e/db_RunningMan.json?raw=1";

	//offline db
	public static String ourDataFilenameNoSlash = "db.json";
	public static String ourDataFilename = "/" + ourDataFilenameNoSlash;
}