package com.muuandmuu.template.func;

/**
 * Created by kingdov on 17/01/2017.
 */

public class DataUrl {
    public String wallName;
    public String wallURL;
    public String wallSite;
    public String wallSiteUrl;
    public int wallIndex;
}
